---
name: siliconforge
description: Use when the user wants to query or control SiliconForge chip engineering tasks through its MCP server, submit chip specs, review evidence, authorize a specific requested action, or read notifications.
---
# SiliconForge User Harness Skill

1. If the user asks status, call `sf_get_status` with project/IP scope. Provide the current Ticket state, latest verified evidence, blockers and next work. Do not infer success from agent activity.
2. If the user describes a new spec or target in natural language, inspect current spec and revision using read tools. Build a precise bounded proposal with expected revision by calling `sf_propose_intent`. Explain any ambiguity only if it affects the requested semantics.
3. If the proposal is within preapproved scope, call `sf_commit_intent` with a unique idempotency key. If approval is required, present the exact scoped change and call `sf_submit_approval` only after a real authorized human decision.
4. If the user asks why an agent acted, call `sf_get_communication`, `sf_list_events` and `sf_get_evidence`. Cite run and event ids; preserve failure and unknown results.
5. Do not impersonate EDA Runner, trusted CI, an authorized approver, or any Domain Owner. Never submit a fabricated PASS event or rewrite quality gates.
6. For notifications, use `sf_get_notifications(cursor)` and `sf_ack_notification` only when the user or configured notification policy authorizes it. Do not run a continual LLM polling loop.
7. Main Agent is a human interface and information broker, not the RTL/Verification/PPA technical decision owner. A direct Owner conversation is a logged peer/human message, not an authority escalation.
