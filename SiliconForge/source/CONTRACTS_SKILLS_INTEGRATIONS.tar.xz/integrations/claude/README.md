# Claude Code User Harness integration

1. Load `CLAUDE.md` and the SiliconForge user skill using the supported Claude Code version's native skills mechanism.
2. Register the same SiliconForge MCP server that Codex uses. Compare read and write receipts across Harnesses.
3. Session-start notification pull is optional and must be confirmed against the installed Hooks API. Push into an active Claude Session is an optional feature, not a contractual prerequisite.
4. The Claude User Harness is a human-facing frontend; the existing Runtime and Codex Owner workers must continue when it exits.
5. Do not create a custom Claude wrapper TUI. The user keeps Claude Code's original interface.
