# Codex User Harness integration

1. Read project `AGENTS.md` and `skills/siliconforge/SKILL.md`.
2. In the installed Codex version, register SiliconForge's **own** MCP server. Verify `sf_get_status` returns a live authenticated response. Do not use the obsolete `codex mcp-server` as the backend Agent-to-Codex integration.
3. Use the official Codex Python SDK (`openai-codex`) for backend Domain Owner threads. It is distinct from the User Harness MCP client route.
4. Disable any long-running model polling for notifications. Use MCP `sf_get_notifications` after restart and Dashboard updates while live.
5. Test cancellation/resume, no-user-session execution, and ExternalMessage lower-trust input before enabling broader automation.

Official references: https://github.com/openai/codex/tree/main/sdk/python and https://developers.openai.com/blog/codex-as-a-platform.
