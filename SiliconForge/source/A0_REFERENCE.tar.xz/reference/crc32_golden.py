"""Independent CRC-32/ISO-HDLC reference algorithm (bitwise, reflected)."""
POLY = 0xEDB88320
MASK = 0xffffffff

class CRC32Engine:
    def __init__(self): self.reset()
    def reset(self):
        self.state=MASK
        self.valid=False
        self.result=0
        self.error=False
    def start(self): self.reset()
    def write_data(self, value:int, byte_count:int):
        if byte_count not in (1,2,3,4):
            self.error=True
            return
        self.valid=False
        self.result=0
        for i in range(byte_count):
            self._byte((value>>(8*i)) & 0xff)
    def _byte(self,b:int):
        x=self.state^b
        for _ in range(8): x=(x>>1)^(POLY if x&1 else 0)
        self.state=x&MASK
    def finish(self):
        self.result=(self.state^MASK)&MASK
        self.valid=True
    def read_result(self): return self.result if self.valid else 0

def crc32_iso_hdlc(payload:bytes)->int:
    c=CRC32Engine()
    for b in payload: c.write_data(b,1)
    c.finish()
    return c.read_result()
