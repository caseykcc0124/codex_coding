"""SiliconForge v3 A0 deterministic reference kernel.

This is explicitly a MOCK-only contract example. No real harness, credentials,
network messaging, EDA execution, or production-grade authentication.
"""
from __future__ import annotations
import hashlib
import json
import sqlite3
import time
from pathlib import Path
from typing import Any

ROUTES = {
    "SPEC.CHANGE_REQUESTED": ("spec",),
    "SIM.REGRESSION_FAILED": ("verification",),
    "RTL.CANDIDATE_READY": ("verification", "formal", "ppa"),
    "FORMAL.PROOF_FAILED": ("formal",),
    "PPA.TARGET_CHANGED": ("ppa",),
    "ENV.PROFILE_REQUIRED": ("eda_environment",),
    "PEER.REQUEST_CREATED": ("$target_owner",),
    "EDA.JOB_COMPLETED": ("$registered_job_owner",),
}
PERMISSIONS = {
    "SPEC.CHANGE_REQUESTED": {"human_gateway"},
    "SIM.REGRESSION_FAILED": {"trusted_ci", "eda_runner"},
    "RTL.CANDIDATE_READY": {"owner:rtl"},
    "FORMAL.PROOF_FAILED": {"eda_runner", "owner:formal"},
    "PPA.TARGET_CHANGED": {"human_gateway"},
    "ENV.PROFILE_REQUIRED": {"runtime", "eda_runner"},
    "PEER.REQUEST_CREATED": {"registered_owner"},
    "EDA.JOB_COMPLETED": {"eda_runner"},
}


def compact(o: Any) -> str:
    return json.dumps(o, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha(o: Any) -> str:
    return hashlib.sha256(compact(o).encode("utf-8")).hexdigest()


class A0Kernel:
    def __init__(self, path: str | Path, now=time.time, lease_seconds=60):
        self.db = sqlite3.connect(str(path), isolation_level=None)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA journal_mode=WAL")
        self.now = now
        self.lease_seconds = lease_seconds
        self.db.executescript("""
            CREATE TABLE IF NOT EXISTS events(
              event_id TEXT PRIMARY KEY, idempotency_key TEXT UNIQUE NOT NULL,
              content_sha TEXT NOT NULL, kind TEXT NOT NULL, source TEXT NOT NULL,
              trace_id TEXT NOT NULL, payload TEXT NOT NULL, created_at REAL NOT NULL);
            CREATE TABLE IF NOT EXISTS deliveries(
              event_id TEXT NOT NULL, owner TEXT NOT NULL, state TEXT NOT NULL,
              lease_epoch INTEGER NOT NULL DEFAULT 0, lease_until REAL,
              attempts INTEGER NOT NULL DEFAULT 0,
              PRIMARY KEY(event_id, owner));
            CREATE TABLE IF NOT EXISTS quarantine(
              qid INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL,
              reason TEXT NOT NULL, source TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS jobs(
              job_id TEXT PRIMARY KEY, requesting_owner TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS fingerprints(
              ticket_id TEXT NOT NULL, failure_signature TEXT NOT NULL,
              repeated_no_progress INTEGER NOT NULL DEFAULT 0,
              PRIMARY KEY(ticket_id, failure_signature));
            CREATE TABLE IF NOT EXISTS tickets(
              ticket_id TEXT PRIMARY KEY, state TEXT NOT NULL DEFAULT 'ACTIVE',
              reason TEXT NOT NULL DEFAULT '');
            CREATE TABLE IF NOT EXISTS notifications(
              notification_id TEXT PRIMARY KEY, recipient TEXT NOT NULL,
              kind TEXT NOT NULL, ticket_id TEXT NOT NULL,
              seq INTEGER NOT NULL UNIQUE, acknowledged INTEGER NOT NULL DEFAULT 0);
            CREATE TABLE IF NOT EXISTS audit(
              seq INTEGER PRIMARY KEY AUTOINCREMENT, action TEXT NOT NULL,
              ref TEXT NOT NULL, data TEXT NOT NULL);
        """)

    def close(self):
        self.db.close()

    def register_job(self, job_id: str, requesting_owner: str):
        with self.db:
            self.db.execute("INSERT INTO jobs VALUES (?,?)", (job_id, requesting_owner))

    def _audit(self, action: str, ref: str, data: dict):
        self.db.execute("INSERT INTO audit(action,ref,data) VALUES (?,?,?)", (action, ref, compact(data)))

    def _route(self, kind: str, payload: dict) -> tuple[str, ...]:
        r = ROUTES.get(kind, ())
        if r == ("$target_owner",):
            v = payload.get("target_owner")
            return (v,) if v in {"spec", "rtl", "verification", "formal", "ppa", "integration", "eda_environment", "pdca"} else ()
        if r == ("$registered_job_owner",):
            row = self.db.execute("SELECT requesting_owner FROM jobs WHERE job_id=?", (payload.get("job_id"),)).fetchone()
            return (row[0],) if row else ()
        return r

    def ingest(self, *, kind: str, source: str, trace_id: str, idempotency_key: str, payload: dict) -> dict:
        """source is a trusted-process argument in this reference only.

        Production must set source from authenticated connection context.
        """
        key = source + ":" + idempotency_key
        content_sha = sha([kind, payload, trace_id])
        self.db.execute("BEGIN IMMEDIATE")
        try:
            prev = self.db.execute("SELECT event_id,content_sha FROM events WHERE idempotency_key=?", (key,)).fetchone()
            if prev:
                if prev["content_sha"] != content_sha:
                    raise ValueError("IDEMPOTENCY_CONFLICT")
                self.db.execute("COMMIT")
                return {"status": "DUPLICATE", "event_id": prev["event_id"]}
            valid = kind in ROUTES and (source in PERMISSIONS[kind] or
                                        (source.startswith("owner:") and "registered_owner" in PERMISSIONS[kind]))
            targets = self._route(kind, payload) if valid else ()
            if not valid or not targets:
                reason = "UNTRUSTED_OR_UNKNOWN" if not valid else "UNROUTABLE"
                self.db.execute("INSERT INTO quarantine(kind,reason,source) VALUES (?,?,?)", (kind, reason, source))
                self._audit("INGRESS.QUARANTINED", key, {"reason": reason})
                self.db.execute("COMMIT")
                return {"status": "QUARANTINED", "reason": reason}
            event_id = sha([key, content_sha])[:32]
            self.db.execute("INSERT INTO events VALUES (?,?,?,?,?,?,?,?)", (event_id, key, content_sha, kind, source, trace_id, compact(payload), self.now()))
            for owner in targets:
                self.db.execute("INSERT INTO deliveries(event_id,owner,state) VALUES (?,?,'READY')", (event_id, owner))
            self._audit("EVENT.ROUTED", event_id, {"targets": targets, "source": source})
            self.db.execute("COMMIT")
            return {"status": "ACCEPTED", "event_id": event_id, "owners": list(targets)}
        except BaseException:
            self.db.execute("ROLLBACK")
            raise

    def claim(self):
        self.db.execute("BEGIN IMMEDIATE")
        try:
            row = self.db.execute("""SELECT d.event_id,d.owner,d.lease_epoch,d.attempts,e.kind,e.trace_id
              FROM deliveries d JOIN events e ON e.event_id=d.event_id
              WHERE d.state='READY' OR (d.state='CLAIMED' AND d.lease_until<=?)
              ORDER BY e.created_at,d.rowid LIMIT 1""", (self.now(),)).fetchone()
            if not row:
                self.db.execute("COMMIT")
                return None
            epoch = row["lease_epoch"] + 1
            self.db.execute("""UPDATE deliveries SET state='CLAIMED', lease_epoch=?,
              attempts=attempts+1, lease_until=? WHERE event_id=? AND owner=?""",
              (epoch, self.now()+self.lease_seconds, row["event_id"], row["owner"]))
            self._audit("DELIVERY.CLAIMED", row["event_id"], {"owner": row["owner"], "epoch": epoch})
            self.db.execute("COMMIT")
            return {**dict(row), "lease_epoch": epoch}
        except BaseException:
            self.db.execute("ROLLBACK")
            raise

    def complete(self, event_id: str, owner: str, lease_epoch: int, *, new_event: dict | None = None):
        self.db.execute("BEGIN IMMEDIATE")
        try:
            result = self.db.execute("""UPDATE deliveries SET state='ACKED',lease_until=NULL
              WHERE event_id=? AND owner=? AND lease_epoch=? AND state='CLAIMED'""", (event_id, owner, lease_epoch))
            if result.rowcount != 1:
                raise PermissionError("STALE_LEASE_FENCED")
            self._audit("DELIVERY.ACKED", event_id, {"owner": owner, "epoch": lease_epoch})
            self.db.execute("COMMIT")
        except BaseException:
            self.db.execute("ROLLBACK")
            raise
        if new_event:
            # For A0 demonstration only: do not use this outside one atomic
            # transaction in production. M1 requires a transactional outbox.
            return self.ingest(**new_event)
        return None

    def observe_failure(self, ticket_id: str, signature: str, progress: bool, limit=3) -> dict:
        with self.db:
            self.db.execute("INSERT OR IGNORE INTO tickets(ticket_id) VALUES (?)", (ticket_id,))
            self.db.execute("""INSERT OR IGNORE INTO fingerprints(ticket_id,failure_signature)
              VALUES (?,?)""", (ticket_id, signature))
            if progress:
                self.db.execute("""UPDATE fingerprints SET repeated_no_progress=0
                  WHERE ticket_id=? AND failure_signature=?""", (ticket_id, signature))
            else:
                self.db.execute("""UPDATE fingerprints SET repeated_no_progress=repeated_no_progress+1
                  WHERE ticket_id=? AND failure_signature=?""", (ticket_id, signature))
            count = self.db.execute("""SELECT repeated_no_progress FROM fingerprints
              WHERE ticket_id=? AND failure_signature=?""", (ticket_id, signature)).fetchone()[0]
            blocked = count >= limit
            if blocked:
                self.db.execute("UPDATE tickets SET state='BLOCKED',reason='NO_PROGRESS' WHERE ticket_id=?", (ticket_id,))
                self._audit("WATCHDOG.BLOCKED", ticket_id, {"signature": signature, "count": count})
            return {"blocked": blocked, "repeated_no_progress": count}

    def notify(self, recipient: str, kind: str, ticket_id: str, notification_id: str):
        with self.db:
            row = self.db.execute("SELECT COALESCE(MAX(seq),0)+1 FROM notifications").fetchone()
            self.db.execute("INSERT OR IGNORE INTO notifications VALUES (?,?,?,?,?,0)",
                            (notification_id, recipient, kind, ticket_id, row[0]))

    def read_notifications(self, recipient: str, cursor=0):
        return [dict(r) for r in self.db.execute("""SELECT * FROM notifications WHERE recipient=? AND seq>?
                  ORDER BY seq""", (recipient, cursor)).fetchall()]

    def acknowledge(self, notification_id: str, recipient: str):
        with self.db:
            r = self.db.execute("UPDATE notifications SET acknowledged=1 WHERE notification_id=? AND recipient=?", (notification_id, recipient))
            return r.rowcount == 1

    def snapshot(self):
        def q(table): return [dict(x) for x in self.db.execute("SELECT * FROM " + table)]
        return {name: q(name) for name in ("events", "deliveries", "tickets", "quarantine", "audit", "notifications")}
