"""Runs a tiny deterministic mock route. NO real agent or EDA is involved."""
import tempfile
from pathlib import Path
from runtime import A0Kernel

with tempfile.TemporaryDirectory() as td:
    k=A0Kernel(Path(td)/'demo.db')
    print(k.ingest(kind='SIM.REGRESSION_FAILED',source='trusted_ci', trace_id='apb_crc32:1',
        idempotency_key='ci-42',payload={'test':'reset_inflight','seed':173}))
    c=k.claim()
    print('routed_to', c['owner'], 'lease_epoch', c['lease_epoch'])
    k.complete(c['event_id'], c['owner'], c['lease_epoch'])
    print('delivered',len(k.snapshot()['deliveries']))
    k.close()
