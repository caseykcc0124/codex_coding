"""A0 contract tests. Mock-only; explicit non-EDA provenance."""
import pytest
from runtime import A0Kernel

@pytest.fixture
def k(tmp_path):
    obj=A0Kernel(tmp_path/'runtime.db')
    yield obj
    obj.close()

def sim(k,key='A',payload=None):
    return k.ingest(kind='SIM.REGRESSION_FAILED',source='trusted_ci',trace_id='crc32-1',idempotency_key=key,payload=payload or {'seed':173})

def test_direct_route_without_main(k):
    e=sim(k)
    assert e['owners']==['verification']
    assert 'main' not in {d['owner'] for d in k.snapshot()['deliveries']}

def test_idempotent_duplicate(k):
    a=sim(k); b=sim(k)
    assert a['event_id']==b['event_id'] and b['status']=='DUPLICATE'
    assert len(k.snapshot()['events'])==1

def test_duplicate_key_different_content_rejected(k):
    sim(k)
    with pytest.raises(ValueError, match='IDEMPOTENCY_CONFLICT'):
        sim(k,payload={'seed':999})

def test_spoofed_eda_report_rejected(k):
    e=k.ingest(kind='EDA.JOB_COMPLETED',source='human_gateway',trace_id='x',idempotency_key='fake',payload={'job_id':'unregistered','owner':'integration'})
    assert e['status']=='QUARANTINED' and len(k.snapshot()['events'])==0

def test_unknown_event_quarantined(k):
    e=k.ingest(kind='AGENT.DO_ANYTHING',source='owner:rtl',trace_id='x',idempotency_key='notyet',payload={})
    assert e['status']=='QUARANTINED'

def test_fanout(k):
    e=k.ingest(kind='RTL.CANDIDATE_READY',source='owner:rtl',trace_id='x',idempotency_key='candidate-1',payload={'rtl_sha':'abc'})
    assert e['owners']==['verification','formal','ppa']
    assert len(k.snapshot()['deliveries'])==3

def test_lease_fencing(tmp_path):
    t=[1000.]
    k=A0Kernel(tmp_path/'fence.db',now=lambda:t[0],lease_seconds=5)
    try:
        sim(k)
        first=k.claim(); t[0]+=6
        second=k.claim()
        assert first['lease_epoch']==1 and second['lease_epoch']==2
        with pytest.raises(PermissionError, match='STALE_LEASE_FENCED'):
            k.complete(first['event_id'],first['owner'],first['lease_epoch'])
        k.complete(second['event_id'],second['owner'],second['lease_epoch'])
        assert k.snapshot()['deliveries'][0]['state']=='ACKED'
    finally: k.close()

def test_restart_replays_claim(tmp_path):
    clock=[1000.]
    path=tmp_path/'restart.db'
    a=A0Kernel(path,now=lambda:clock[0],lease_seconds=4)
    sim(a); first=a.claim();a.close()
    clock[0]+=5
    b=A0Kernel(path,now=lambda:clock[0],lease_seconds=4)
    second=b.claim()
    assert first['event_id']==second['event_id'] and second['lease_epoch']==2
    b.close()

def test_job_owner_from_registry_not_payload(k):
    k.register_job('job-1','verification')
    e=k.ingest(kind='EDA.JOB_COMPLETED',source='eda_runner',trace_id='x',idempotency_key='eda1',payload={'job_id':'job-1','owner':'integration'})
    assert e['owners']==['verification']

def test_unregistered_job_quarantined(k):
    e=k.ingest(kind='EDA.JOB_COMPLETED',source='eda_runner',trace_id='x',idempotency_key='eda1',payload={'job_id':'invalid','owner':'integration'})
    assert e['status']=='QUARANTINED'

def test_repeat_failure_stops_after_three(k):
    for i in range(2): assert not k.observe_failure('T1','crc_mismatch',False)['blocked']
    assert k.observe_failure('T1','crc_mismatch',False)['blocked']
    assert k.snapshot()['tickets'][0]['reason']=='NO_PROGRESS'

def test_progress_resets_counter(k):
    k.observe_failure('T1','sig',False)
    k.observe_failure('T1','sig',True)
    assert k.observe_failure('T1','sig',False)['repeated_no_progress']==1

def test_blocked_ticket_does_not_block_other_ip(k):
    k.observe_failure('IP-A','sig',False,limit=1)
    e=k.ingest(kind='PPA.TARGET_CHANGED',source='human_gateway',trace_id='IP-B',idempotency_key='p1',payload={'mhz':100})
    assert e['status']=='ACCEPTED' and k.claim()['owner']=='ppa'

def test_notification_survives_restart(tmp_path):
    path=tmp_path/'n.db'
    x=A0Kernel(path);x.notify('human-1','BLOCKED','T1','notif1');x.close()
    y=A0Kernel(path)
    assert len(y.read_notifications('human-1'))==1
    assert y.acknowledge('notif1','human-1')
    assert y.read_notifications('human-1')[0]['acknowledged']==1
    y.close()

def test_notification_duplicate_does_not_duplicate(k):
    k.notify('human','BLOCKED','T1','same')
    k.notify('human','BLOCKED','T1','same')
    assert len(k.read_notifications('human'))==1

def test_reception_after_idle(k):
    sim(k,key='one');x=k.claim();k.complete(x['event_id'],x['owner'],x['lease_epoch'])
    assert k.claim() is None
    sim(k,key='two'); assert k.claim() is not None
