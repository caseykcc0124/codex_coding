import random
import zlib
from crc32_golden import CRC32Engine,crc32_iso_hdlc

def test_standard_vector():
    assert crc32_iso_hdlc(b'123456789')==0xCBF43926

def test_reference_matches_python_zlib_on_random_payloads():
    r=random.Random(20261107)
    for _ in range(20):
        data=r.randbytes(r.randrange(0,120))
        assert crc32_iso_hdlc(data)==zlib.crc32(data)

def test_reset_prevents_old_result_read():
    c=CRC32Engine();c.write_data(0x12345678,4);c.finish()
    assert c.valid
    c.reset()
    assert not c.valid and c.read_result()==0

def test_illegal_byte_count_is_non_mutating():
    c=CRC32Engine();c.write_data(123,1); old=c.state
    c.write_data(123,5)
    assert c.error and c.state==old
