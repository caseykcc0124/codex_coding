from pathlib import Path
import json
import jsonschema
import yaml
ROOT=Path(__file__).resolve().parents[1]

def test_all_contracts_are_valid_json_schemas():
    found=list((ROOT/'contracts').glob('*.json'))
    assert len(found)>=10
    for f in found:
        jsonschema.Draft202012Validator.check_schema(json.loads(f.read_text()))

def test_all_policies_are_valid_yaml():
    for f in (ROOT/'config').glob('*.yaml'):
        assert isinstance(yaml.safe_load(f.read_text()),dict)

def test_router_has_direct_verification_not_main():
    r=yaml.safe_load((ROOT/'config/routes.yaml').read_text())
    rule=next(x for x in r['rules'] if x['type']=='SIM.REGRESSION_FAILED')
    assert rule['primary_owner']=='verification'
    assert all('main'!=x.get('primary_owner') for x in r['rules'])

def test_policy_disallows_runtime_self_expansion():
    p=yaml.safe_load((ROOT/'config/autonomy.yaml').read_text())
    assert 'increase_budget' in p['requires_human_approval']
    assert 'install_eda_tools' in p['forbidden_owner_actions']

def test_source_docs_present():
    for name in ('00_MISSION_AND_BOUNDARIES.md','01_ARCHITECTURE_AND_DECISION_RIGHTS.md','02_EVENT_RUNTIME_PROTOCOL.md','03_OWNER_PSTACK_EDA_WORKFLOWS.md','04_HARNESS_MCP_HUMAN_INTERFACE.md','05_OBSERVABILITY_PDCA_AND_DASHBOARD.md','06_IMPLEMENTATION_ROADMAP.md','07_ACCEPTANCE_MATRIX.md','08_CODING_AGENT_WORK_ORDER.md','09_SCENARIOS_AND_FAILURE_INJECTION.md'):
        assert (ROOT/'docs'/name).is_file()
